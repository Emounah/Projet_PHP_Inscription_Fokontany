# Madagascar-map

`MG : `Lisitr'ireo fokontany, kaominina , distrika, Région eto Madagasikara.

`FR : ` Liste des communes, district, ville et Région de Madagascar.

`EN : ` list of municipalities, district, towns, Region of Madagascar

## Features :

- Exposition des données via API ( api-plateforme )
- Ajout Coordonnées Géographique
- Ajout liste population
- Web UI

**Code for fun !**
